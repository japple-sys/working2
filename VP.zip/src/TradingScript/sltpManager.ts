require("mongoose").connect("mongodb://localhost:27017/sniping");
import { Connection, Keypair, PublicKey } from "@solana/web3.js";
import { splSwap } from ".";
import { Snipe, Snipingtoken, User } from "../Database/models";
import engineBot from "../TelegramBot/Bot";
import { getOrCreateAssociatedTokenAccount } from "@solana/spl-token";
import bs58 from "bs58";
import { BotCaption } from "../TelegramBot/constants";

export async function sltpManager() {
  try {
    // Fetch all tokens from the database
    const tokens = await Snipingtoken.find();
    const Snipes = await Snipe.find({ status: "sniping" });
    const validTokens = tokens.filter( item => item.splToken && item.splToken.trim() !== "" );
    const mergedMintAddresses = validTokens.map((item) => item.splToken).join(",");
    const solAddress = "So11111111111111111111111111111111111111112";
    const priceResponseShowExtraInfo = await fetch(`https://api.jup.ag/price/v2?ids=${solAddress},${mergedMintAddresses}&showExtraInfo=true`);
    const priceDataShowExtraInfo = await priceResponseShowExtraInfo.json();
    Snipes.forEach((snipe: any) => {
      const tpSolAmount = (snipe.inAmount * snipe.takeProfit) / 100;
      // console.log("tpSolAmount: ",tpSolAmount);
      const slSolAmount = (snipe.inAmount * (100 - snipe.stopLoss)) / 100;
      // console.log(slSolAmount);
      const solPrice = parseFloat( priceDataShowExtraInfo.data[solAddress]?.price );
      const tokenPrice = parseFloat( priceDataShowExtraInfo.data[snipe.splToken]?.price );
      const expectedSolAmount = ((tokenPrice / solPrice) * snipe.outAmount) / 10 ** snipe.decimals; 
      if (expectedSolAmount > tpSolAmount) {
        // console.log( `📈take profit\n${expectedSolAmount}: ${snipe.tokenAmount}: ${solPrice}: ${tokenPrice}: ${snipe.tokenDecimals}` );
				swapProcess(snipe.splToken, snipe.slippage, snipe.fee, snipe.tip, snipe.userId);
      } else if (expectedSolAmount < slSolAmount) {
        // console.log( `stop loss\n${expectedSolAmount}: ${snipe.tokenAmount}: ${solPrice}: ${tokenPrice}: ${snipe.tokenDecimals}` );
				swapProcess(snipe.splToken, snipe.slippage, snipe.fee, snipe.tip, snipe.userId);
      } else {
        console.log(`🎯 sniping... ${snipe.splToken} ${tokenPrice} ${solPrice} ${snipe.outAmount} ${snipe.decimals} ${expectedSolAmount} ${tpSolAmount} ${slSolAmount}`);
				console.log(priceDataShowExtraInfo)
      }
    });
  } catch (error) {
    console.error("Error fetching tokens:", error);
  }
}

async function swapProcess(splToken:string, slippage:number, fee:number, tip:number, userId:number) {
	if (!process.env.RPC_URL) { throw new Error("⚠ RPC Node Error"); }
	const connection = new Connection(process.env.RPC_URL, "confirmed");
	const user = await User.findOne({userId:userId});
  if(!user || !user.priKey){
    engineBot.telegram.sendMessage(userId, BotCaption.invalidWallet)
    return;
  }
	const keypair = Keypair.fromSecretKey(bs58.decode(user.priKey));
	const Ata = await getOrCreateAssociatedTokenAccount(
    connection,
    keypair,
    new PublicKey(splToken),
    keypair.publicKey
);
  const tokenAmount = await connection.getTokenAccountBalance(Ata.address);
  const sellAmount = tokenAmount.value.uiAmount || 0;
	if(!sellAmount){
		// await Snipe.deleteOne({userId:userId, splToken:splToken, status:"sniping"});
		// engineBot.telegram.sendMessage(userId, `⚠ Token Not Existing on your Wallet ⚠\n Please wait for a few seconds\n Buy trnasaction seems failed accidently, please check wallet balance and token security, thanks`);
		// const usersnipe = await Snipe.find({userId:userId, splToken:splToken, status:"sniping"});
		// if (usersnipe.length){
			
		// }
		return;
	}
	const { bundleResult, inAmount, outAmount } = await splSwap( connection, splToken, sellAmount, slippage, fee, tip, user.priKey, false) || { bundleResult: "", inAmount: 0, outAmount: 0 };
	if(bundleResult){
		// Here snipe update code🔥🔥🔥 🔥🔥🔥 🔥🔥🔥
		const endingSnipe = await Snipe.find({userId:userId, splToken:splToken, status:"sniping"});
		console.log("🍏 endingsnipe info: ",endingSnipe[0])
		if(endingSnipe.length){
			endingSnipe[0].sellTx = bundleResult;
			endingSnipe[0].status = "success";
			await endingSnipe[0].save();
			if(!endingSnipe[0].isAutoSnipe){
				const solchange = outAmount - endingSnipe[0].inAmount;
				if(solchange>0){  // Took Profit
					engineBot.telegram.sendMessage(userId, `🍌 Successfully ended Specific Snipe With Taking Profit!\n Profit: ${solchange} SOL
View on <a href='https://solscan.io/tx/${bundleResult}?chain=solana'>Solscan</a>`, {parse_mode: "HTML"});
				} else {
					engineBot.telegram.sendMessage(userId, `🛡 Successfully ended Specific Snipe With Stoping Loss!\n Loss: ${solchange} SOL
View on <a href='https://solscan.io/tx/${bundleResult}?chain=solana'>Solscan</a>`, {parse_mode: "HTML"});
				}
			}
		} else {
			console.log("⚠ Not found sniping for the token");
		}
	}
}
