import { Keypair, Connection, LAMPORTS_PER_SOL, VersionedTransaction, PublicKey } from "@solana/web3.js";
import { getSwapInfo, getSwapTransaction } from "./jupiterService";
import { NATIVE_MINT, getMint } from "@solana/spl-token";
import { sendBundle } from "./jitoService";
import { Wallet } from "@project-serum/anchor";
import bs58 from "bs58";
import dotenv from 'dotenv';

dotenv.config();

export const splSwap = async (connection:Connection, spl:string, inAmount:number, slippage:number, fee:number, tip:number, priKey:string, isBuy:Boolean) => {
  const decimals = (await getMint(connection, new PublicKey(spl))).decimals;
  let success = false;
  while (success == false) {
    const buyer = Keypair.fromSecretKey(bs58.decode(priKey));
    const buyerAnchorWallet = new Wallet(buyer);
    const swapInfo = isBuy
      ? await getSwapInfo(NATIVE_MINT.toBase58(), spl, inAmount * LAMPORTS_PER_SOL, slippage)
      : await getSwapInfo(spl, NATIVE_MINT.toBase58(), inAmount * 10**decimals, slippage);
    if(!swapInfo){
      console.log("⚠ Token is not tradable on Jupiter ⚠");
      // here swap with myfun module
      return null;
    }
    const outAmount = isBuy ? swapInfo.outAmount / 10 ** decimals : swapInfo.outAmount / LAMPORTS_PER_SOL;
    const Txn = await getSwapTransaction( swapInfo, buyerAnchorWallet, fee );
    if (Txn == null) { continue; }
    const swapTxnBuf = Buffer.from(Txn, "base64");
    const latestBlockHash = await connection.getLatestBlockhash();
    const vTxn = VersionedTransaction.deserialize(swapTxnBuf);
    vTxn.message.recentBlockhash = latestBlockHash.blockhash;
    vTxn.sign([buyerAnchorWallet.payer]);

    let bundleResult = "";
    try {
      bundleResult = await sendBundle(connection, vTxn, tip) || "";
      success = true;
      return {bundleResult, inAmount, outAmount};
    } catch (error) {
      await new Promise((resolve) => setTimeout(resolve, 10000));
      return null;
    }
  }
  process.exit(0);
};