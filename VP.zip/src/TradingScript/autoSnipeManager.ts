// import WebSocket from 'ws';
// import dotenv from 'dotenv';
// const sleep = require('await-sleep');
// import { getMint, TOKEN_PROGRAM_ID } from "@solana/spl-token";
// import {
//     Connection,
//     clusterApiUrl,
//     PublicKey
// } from '@solana/web3.js';
// import { extractMintAccountFromTransaction, getLiquidity } from '../Liquidity';
// import { rugScoreWithApi } from '../Rugcheck';
// import { AutoSnipe, Snipe, Snipingtoken, User } from '../Database/models';
// import engineBot from '../TelegramBot/Bot';
// import { splSwap } from '.';
// import { BotCaption } from '../TelegramBot/constants';
// import { specsnipebuysuccesscard } from '../TelegramBot/uigenerator';
// import { getTokenOverView } from '../Birdeye';

// dotenv.config();
// const RPC_URL = process.env.RPC_URL || clusterApiUrl('mainnet-beta');
// const connection = new Connection(RPC_URL, 'confirmed');

// connection.onLogs(new PublicKey("675kPX9MHTjS2zt1qfr1NYHuzeLXfQM9H24wFSUt1Mp8"), async (txn) => {
//   const logs = txn.logs;
//   const hasCrtIxn = logs.some(log => log.includes('initialize2'));
//   if(hasCrtIxn){
//     const vTxn = await connection.getTransaction(txn.signature, {
//       commitment: 'confirmed',
//       maxSupportedTransactionVersion: 0
//     });
//     const [mintAccount, poolAddress] = await extractMintAccountFromTransaction(vTxn);
//     if (mintAccount && poolAddress) {
//       if (mintAccount.toBase58() === "So11111111111111111111111111111111111111112") return;
//       await sleep(3000);
//       const {risks, score} = await rugScoreWithApi(mintAccount.toBase58());
//       const liquidity = await getLiquidity(connection, poolAddress.toBase58()) || 0;
//       console.log("🟢",score, liquidity);
//       const autosnipes = await AutoSnipe.find({enable: true})
//       if(autosnipes.length){
//         autosnipes.forEach(snipe => {
//           let okayLiquidity = false;
//           let okayRiskScore = false;
//           liquidity >= snipe.minLiquidity? okayLiquidity = true: okayLiquidity = false;
//           if (snipe.riskScore == "LOW"){
//             score <= 100? okayRiskScore = true: okayRiskScore = false;
//           } else if (snipe.riskScore == "MEDIUM"){
//             score > 100 && score <= 400? okayRiskScore = true: okayRiskScore = false;
//           } else if (snipe.riskScore == "HIGH"){
//             score > 400? okayRiskScore = true: okayRiskScore = false;
//           } else {
//             okayRiskScore = false;
//           }
//           if (okayLiquidity && okayRiskScore){
//             // Buy action
//             buySwapProcess(connection, mintAccount.toBase58(), snipe.eachAmount, snipe.slippage, 0.00002, 0.000001, snipe.userId, snipe.takeProfit, snipe.stopLoss);
//           }
//         });
//       }
//     }
//   }
// }, "confirmed");

// // (async () => {
// //   const vTxn = await connection.getTransaction("4cDM3P6mMZx5wfCXEkGAy3fb6es2uZx5CAzLHv78GXDmjqU4xyLuRUauzqMfR2HMuMXnsFSdj385evbKaaK5Waoi", {
// //   commitment: 'confirmed',
// //   maxSupportedTransactionVersion: 0
// //   });
// //   const [mintAccount, poolAddress] = await extractMintAccountFromTransaction(vTxn);
// //   console.log(mintAccount, poolAddress)
// // }
// // )();

// async function buySwapProcess(connection:Connection, splToken:string, buyAmount:number, slippage:number, fee:number, tip:number, userId:number, takeProfit:number, stopLoss:number){
//   const user = await User.findOne({userId:userId});
//   if(!user || !user.priKey){
//     engineBot.telegram.sendMessage(userId, BotCaption.invalidWallet)
//     return;
//   }
//   const {bundleResult, inAmount, outAmount} 
//     = await splSwap(connection, splToken, buyAmount, slippage, fee, tip, user.priKey, true) 
//     || {bundleResult:"", inAmount:0, outAmount:0};
//   if(bundleResult){
//     const decimals = (await getMint(connection, new PublicKey(splToken))).decimals;
//     await Snipe.create({
//       userId: userId,
//       splToken: splToken,
//       inAmount: inAmount,
//       outAmount: outAmount,
//       slippage: slippage,
//       takeProfit: takeProfit,
//       stopLoss: stopLoss,
//       fee: fee,
//       tip: tip,
//       buyTx: bundleResult,
//       sellTx: "",
//       status: "sniping",
//       isAutoSnipe: true,
//       decimals: decimals
//     })
//     const hasTokenOnList = await Snipingtoken.find({splToken:splToken});
//     if(!hasTokenOnList.length){
//       console.log("🔥🔥🔥🔥🔥", splToken);
//       await Snipingtoken.create({splToken: splToken});
//     }
//     const tokenOverView = await getTokenOverView(new PublicKey(splToken));
//     const card = await specsnipebuysuccesscard(tokenOverView?.symbol || "new", bundleResult, inAmount, outAmount);
//     await engineBot.telegram.sendMessage(userId, card.description, {parse_mode:"HTML"});
//   } else {
//     await engineBot.telegram.sendMessage(userId, BotCaption.SWAP_FAILED);
//   }
// }