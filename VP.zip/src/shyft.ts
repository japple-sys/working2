import Client, { CommitmentLevel, SubscribeRequest } from "@triton-one/yellowstone-grpc";

const req: SubscribeRequest = {
  "slots": {
    "slots": {}
  },
  "accounts": {},
  "transactions": {
    "raydiumPoolv4": {
      "vote": false, //optional
      "failed": false, //optional
      "accountInclude": ["2ois1yQ7pEQjQkjohnN9rYBk8HWmAfCStWCFzc535W72"], //updates streamed for these accounts
      "accountExclude": [], //updates for this will be excluded
      "accountRequired": []
    }
  },
  "blocks": {},
  "blocksMeta": {},
  "accountsDataSlice": [],
  "commitment": CommitmentLevel.CONFIRMED //finalized or processed also available
  ,
  "transactionsStatus": {},
  "entry": {}
}

const client = new Client(
  "wss://rpc.shyft.to",
  "rPpbsO5iImY6EsFi",
  undefined
); //initializing yellowstone client

const stream = await client.subscribe();
