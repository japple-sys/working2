import { Chart, registerables } from 'chart.js';
import { createCanvas } from 'canvas';
import * as fs from 'fs';

// Register Chart.js components
Chart.register(...registerables);

// Function to read data from the log file and convert it to the desired format
const readDataPoints = (filePath: string): number[][] => {
    // Read the file synchronously
    const data = fs.readFileSync(filePath, 'utf-8');

    // Split the data into lines and map to the desired format
    const dataPoints: number[][] = data.split('\n')
        .filter(line => line.trim() !== '') // Filter out empty lines
        .map(line => {
            const [time, value] = line.split(' ').map(Number); // Split and convert to numbers
            return [time, value];
        });

    // Sort data points by time (ascending order)
    dataPoints.sort((a, b) => a[0] - b[0]);

    return dataPoints;
};

// Specify the path to your log file
const filePath = 'src/logs/logs/draw.log';

// Get the data points
const dataPoints = readDataPoints(filePath);

// Prepare data for the chart
const labels = dataPoints.map(point => point[0].toString());
const values = dataPoints.map(point => point[1]);

// Create a canvas
const canvas = createCanvas(800, 400);
const ctx = canvas.getContext('2d');

// Create the chart
const myChart = new Chart(ctx as unknown as CanvasRenderingContext2D, {
    type: 'line',
    data: {
        labels: labels,
        datasets: [{
            label: 'Data Values',
            data: values,
            fill: false,
            borderColor: 'rgb(75, 192, 192)',
            tension: 0.1
        }]
    },
    options: {
        scales: {
            x: {
                title: {
                    display: true,
                    text: 'Time'
                }
            },
            y: {
                title: {
                    display: true,
                    text: 'Data'
                }
            }
        }
    }
});

// Save the chart as an image
const buffer = canvas.toBuffer('image/png');
fs.writeFileSync('chart.png', buffer);
console.log('Chart saved as chart.png');