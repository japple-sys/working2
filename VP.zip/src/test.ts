import Client, {
  CommitmentLevel,
  SubscribeRequestAccountsDataSlice,
  SubscribeRequestFilterAccounts,
  SubscribeRequestFilterBlocks,
  SubscribeRequestFilterBlocksMeta,
  SubscribeRequestFilterEntry,
  SubscribeRequestFilterSlots,
  SubscribeRequestFilterTransactions,
} from "@triton-one/yellowstone-grpc";
import { VersionedTransactionResponse } from "@solana/web3.js";
import { tOutPut } from "./utils/transactionOutput";
import { searchForInitialize2 } from "./utils/logTXN";
import { SubscribeRequestPing } from "@triton-one/yellowstone-grpc/dist/types/grpc/geyser";
import { SUB_TXN, END_TXN } from "./constants";
import { sleep } from "@raydium-io/raydium-sdk-v2";

interface SubscribeRequest {
  accounts: { [key: string]: SubscribeRequestFilterAccounts };
  slots: { [key: string]: SubscribeRequestFilterSlots };
  transactions: { [key: string]: SubscribeRequestFilterTransactions };
  transactionsStatus: { [key: string]: SubscribeRequestFilterTransactions };
  blocks: { [key: string]: SubscribeRequestFilterBlocks };
  blocksMeta: { [key: string]: SubscribeRequestFilterBlocksMeta };
  entry: { [key: string]: SubscribeRequestFilterEntry };
  commitment?: CommitmentLevel | undefined;
  accountsDataSlice: SubscribeRequestAccountsDataSlice[];
  // ping?: SubscribeRequestPing | undefined;
  ping?: SubscribeRequestPing;
}

const TOKEN = "6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P";
const client = new Client(
  "https://grpc.va.shyft.to",
  "01533e4e-626d-41d5-9d78-f36e10148418",
  undefined
);

async function handleStream(client: Client, args: SubscribeRequest) {
  // Subscribe for events
  const stream = await client.subscribe();

  // Create `error` / `end` handler
  const streamClosed = new Promise<void>((resolve, reject) => {
    stream.on("error", (error) => {
      console.log("ERROR", error);
      reject(error);
      stream.end();
    });
    stream.on("end", () => {
      resolve();
    });
    stream.on("close", () => {
      resolve();
    });
  });

  // Handle updates
  stream.on("data", async (data) => {
    try {
      const result = await tOutPut(data);
      if (result.signature == "") return;
      console.log("☢",result.signature);
    } catch (error) {
      if (error) {
        console.log(error);
      }
    }
  });

  // Send subscribe request
  await new Promise<void>((resolve, reject) => {
    stream.write(args, (err: any) => {
      if (err === null || err === undefined) {
        resolve();
      } else {
        reject(err);
      }
    });
  }).catch((reason) => {
    console.error(reason);
    throw reason;
  });

  await streamClosed;

  return stream;
}
let flag = true;
async function subscribeCommand(client: Client, args: SubscribeRequest) {
  while (flag) {
    try {
      const stream = await handleStream(client, args);
      await sleep(3000);
      console.log("🍺");
      stream.end();
      await updateSubscription(stream, END);
      flag = false;
      console.log("☺");

    } catch (error) {
      console.error("Stream error, restarting in 1 second...", error);
      await new Promise((resolve) => setTimeout(resolve, 1000));
    }
  }
}

async function updateSubscription(stream: any, args: SubscribeRequest) {
  try {
    // Send the updated request to the stream
    stream.write(args);
  } catch (error) {
    console.error("Failed to send new request:", error);
  }
}

const START = {
  accounts: {},
  slots: {},
  transactions: {
    raydiumPoolv4: {
      vote: false,
      failed: false,
      signature: undefined,
      accountInclude: [TOKEN],
      accountExclude: [],
      accountRequired: [],
    },
  },
  transactionsStatus: {},
  entry: {},
  blocks: {},
  blocksMeta: {},
  accountsDataSlice: [],
  ping: undefined,
  commitment: CommitmentLevel.CONFIRMED, //for receiving confirmed txn updates
};
const END = {
  accounts: {},
  slots: {},
  transactions: {
    raydiumPoolv4: {
      vote: false,
      failed: false,
      signature: undefined,
      accountInclude: [],
      accountExclude: [],
      accountRequired: [],
    },
  },
  transactionsStatus: {},
  entry: {},
  blocks: {},
  blocksMeta: {},
  accountsDataSlice: [],
  ping: undefined,
  commitment: CommitmentLevel.CONFIRMED, //for receiving confirmed txn updates
};

import express from "express";

const app = express();
app.use(express.json());

let subscribedWallets: string[] = []; // Store wallets in memory

// Get all subscribed wallets
app.get("/wallets", (req:any, res:any) => {
  res.json(subscribedWallets);
});

// Add a new wallet
app.get("/wallets/add", (req:any, res:any) => {
  const { address } = req.query;

  if (!address || typeof address !== "string") {
    return res.status(400).json({ error: "Address is required and must be a string" });
  }

  const addresses = address.split(',');

  const validAddresses = addresses.filter(addr => typeof addr === "string" && addr.trim() !== "");

  if (validAddresses.length === 0) {
    return res.status(400).json({ error: "No valid addresses provided" });
  }

  // Add the new addresses to the subscribed list
  subscribedWallets = [...validAddresses];
  res.json({ success: true, wallets: subscribedWallets });
});


app.delete("/wallets/:address", (req, res) => {
  const { address } = req.params;


  if (!subscribedWallets.includes(address)) {
    return res.status(404).json({ error: "Wallet not found" });
  }

  
  subscribedWallets = subscribedWallets.filter((w) => w !== address);
  res.json({ success: true, wallets: subscribedWallets });
});

app.listen(3000, () => console.log("API running on http://localhost:3000"));