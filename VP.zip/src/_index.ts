import { config } from "dotenv";
import { BotCaption, Ixn } from "./constants";
import { Connection, LAMPORTS_PER_SOL, PublicKey } from "@solana/web3.js";
import logger from "./logs/logger";
import { splSwap } from "./TradingScript";
import { sleep } from "@raydium-io/raydium-sdk-v2";
import { LIQUIDITY_STATE_LAYOUT_V4 } from "@raydium-io/raydium-sdk";
import { TransactionInstruction } from "@solana/web3.js";
import { SystemProgram } from "@solana/web3.js";
import { Transaction } from "@solana/web3.js";
import { ComputeBudgetProgram } from "@solana/web3.js";
const {
    ASSOCIATED_TOKEN_PROGRAM_ID,
    TOKEN_PROGRAM_ID
} = require("@solana/spl-token");

const PUMP_FUN_PROGRAM = new PublicKey("6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P");
const PUMP_FUN_ACCOUNT = new PublicKey("Ce6TQqeHC9p8KetsN6JsjHK7UTZk7nasjjnr7XxXp9F1")

config();
if(!process.env.RPC_URL){throw new Error(BotCaption.InvaildRPC_URL)}

const connection = new Connection(process.env.RPC_URL, 'confirmed');

// connection.onLogs(new PublicKey("39azUYFWPz3VHgKCf3VChUwbpURdCHRxjWVowf5jUJjg"), async(res) => {
//     const { signature, err, logs } = res;
//     console.log(signature)
//     if(logs.some(log => log.includes(Ixn.Initiate))){
//         console.log("👍")
//         const splToken = await getSplfromInitiate(signature) || "";
//         logger.info(splToken);
//         if(splToken == "4BY4DLoo7zodJm6W1MxVwbL2dZ73vp6dpM3uSzEHpump"){
//             console.log("🙏🙏🙏🙏🙏🙏");
//         }
//         sleep(3000);
//         const { bundleResult, inAmount, outAmount } = await splSwap(connection, splToken, 0.0001, 100, 0.00002, 0.000001, "3aUabi8fd4gqH8Yova1wJ3WV9HXjPUWnAY1eUB3rFytjVuUb83VwvaMRESNx2tBSrKpS5C4n7TaTxsFJBPJvA3xR", true) || {bundleResult: "", inAmount: 0, outAmount: 0 };
//         logger.info(`🙏${bundleResult}`);
//     }
// });




// async function getSpl(signaturee: string) {
//     const Txn = await connection.getParsedTransaction(signaturee, { commitment: "confirmed", maxSupportedTransactionVersion: 0 });
//     const Ixns = Txn?.transaction.message.instructions || [];
//     for (const Ixn of Ixns){
//         if ("parsed" in Ixn && "info" in Ixn.parsed && "mint" in Ixn.parsed.info){
//             const parsed = Ixn.parsed;
//             const mint = parsed.info?.mint;
//             // console.log("mint: ",mint);
//             return mint;
//         }
//     }
//     return null;
// }



// (async () => {const kkk = await getSpl("3boq7uq5WqrUsgnyaXbd8w1S3fhKPwBcVf3hnJTudtRSjm1sNw2igzwiXyE9pyDSP5rpMsHuzRrU2a9dgT9PdnHF");console.log(kkk)})();
(async () => {  
    // const data = await connection.getTokenAccountsByOwner(
    //     new PublicKey("kki478MyjVpECpDkn3PsbuWE3xkm6hMGkvLQhpYBLWR"), 
    //     { programId: new PublicKey("TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA") }
    // )
    // const txs = data.value;
    // txs.forEach((txn, index) => {
    //     console.log(index, txn.pubkey.toBase58())
    // })

    // const sig = await connection.getSignaturesForAddress(new PublicKey("EuVTNU5Q4v7AURBcCQM1aw3YgEj4UfhqD8nzxay4YCEn")); // 💚
    // // console.log(sig)
    // const signatures: string[] = sig.map(transaction => transaction.signature);
    // // let data = await connection.getParsedTransactions(signatures, {maxSupportedTransactionVersion:0})
    // console.log(signatures)

    // 205633 6DNtfSv8beqDJdrb7v2cmH8FNJT8XAt7cLnRoiy5sppV

    // const splToken = new PublicKey("464WwWNTgP3yuFusD9JvEsBFQVNZLbN2fPc25EJ9pump");
    // const PUMP_FUN_PROGRAM = new PublicKey("6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P");
    // const [bondingCurve] = PublicKey.findProgramAddressSync( [ Buffer.from("bonding-curve"), splToken.toBuffer() ], PUMP_FUN_PROGRAM);
    // const lamports = (await connection.getAccountInfo(splToken))?.owner.toBase58() == "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
    // console.log(lamports)
    
    // const fees = await connection.getRecentPrioritizationFees({lockedWritableAccounts: [new PublicKey("675kPX9MHTjS2zt1qfr1NYHuzeLXfQM9H24wFSUt1Mp8")]});
    // let sum = 0.0;
    // fees.forEach(fee => {
    //     sum += fee.prioritizationFee
    // })
    // console.log(sum)
    // console.log(fees)
    // const limitIxn = ComputeBudgetProgram.setComputeUnitLimit({units: 300_000});
    // const priceIxn = ComputeBudgetProgram.setComputeUnitPrice({microLamports: 1});
    // const transferAmount = 0.01;
    // const transferIxnIndex = 2;
    // const IxnData = Buffer.alloc(4 + 8);
    // console.log(IxnData);
    
    // IxnData.writeUint32LE(transferIxnIndex, 0);
    // IxnData.writeBigUInt64LE(BigInt(transferAmount*LAMPORTS_PER_SOL), 4);
    // const transferIxn = new TransactionInstruction({
    //     keys: [
    //         { pubkey: sender.publicKey, isSigner: true, isWritable: true },
    //         { pubkey: receiver.publicKey, isSigner: false, isWritable: true },
    //     ],
    //     programId: SystemProgram.programId,
    //     data: IxnData
    // });
    // const Txn = new Transaction().add(transferIxn);

    // const aaa = await connection.getTokenAccountBalance(new PublicKey("A7Sszg5CQmEjKqFA64d6ynFTXxmhEYfrZ44c4CjMEfqj"));
    // console.log(aaa)
    // data.value.forEach(async item => {
    //     // const poolData = (item.account.data)
    //     // console.log(item.pubkey)
        
    //     // const parsed = Buffer.from(item.account.data);
    //     // console.log(parsed)
    // })
    // const dd = await connection.getParsedAccountInfo(data.value[3].pubkey);
    // const dd = await connection.getAccountInfo(new PublicKey("3QV8yr9gQqMmB6zdEzkTxPE7PJcFfXhz9qW8NTxiyV74"));
    // console.log(JSON.stringify(dd, null, 2))
    
        // console.log(Buffer.from(dd.value?.data as any, "utf-8").toString('hex'))
        // const hexString: string = "17b7f83760d8ac6000000000000000000000000000000000000000000000000000000000000000000080c6a47e8d030001";

        // // Get the last character
        // const lastCharacter: string = hexString[hexString.length - 1];
        
        // console.log(`Last character: ${lastCharacter}`);
    
    
    // const lll = await connection.getParsedTransaction(
    //     "3712m3EvfBjeaFg4xAFknLeTnacM1gRRqpFAdueS4XuYdR8e278ufSLucGsZWQwE1wKo2prFw2tsSViNU6xKio4w",
    //     { commitment: "confirmed", maxSupportedTransactionVersion: 0 }
    // );
    // console.log(lll?.transaction.message.instructions)
    // console.log("👍", lll?.transaction.message.instructions[7])
    // if (lll?.meta?.innerInstructions?.length && lll?.meta?.innerInstructions[1].instructions){
    //     console.log(lll?.meta?.innerInstructions[1].instructions)
    //     if("parsed" in lll?.meta?.innerInstructions[1].instructions[2]){
    //         const parsed = lll?.meta?.innerInstructions[1].instructions[2].parsed;
    //         console.log(parsed);
    //     } else {
    //         console.log("😡")
    //     }
    // }
    // console.log("👍", lll?.transaction.message.accountKeys[18].pubkey.toBase58())
})();

// 5DCXTFb3U98GzkPr52CH5RJHJ1chxHeQQgaPzT65ZSrfRkJ1sssDugkz3hx9VTBifgEvyetaTJFW3KgwcwwfUNjt
// 3RdFZpFvbMBc2HnNjLPUQZCJNZerrESS8iczYSpyBjub2w3EDc97TyPbbKD9BU66Gkc3vXihVpUtS2r6LNaT4hbw
// 2JDQjc6k7JypfjkVbgdVD1DyPhJoXf3z44J8qQ7fzsmFMQ8Wxoys89Yr1TuJDM2NLkJU6S6WzjTLSkJo67kRHMwP

