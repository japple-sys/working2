import { config } from "dotenv";
import { BotCaption } from "./constants";
import { Connection, LAMPORTS_PER_SOL, SystemProgram } from "@solana/web3.js";
import { getRaydiumPools, isGraduated, signature2solbalance } from "./Functions/zeus";
import { PublicKey } from "@solana/web3.js";
import logger from "./logs/logger";
import axios from "axios";
import * as fs from 'fs';
import { Metaplex } from "@metaplex-foundation/js";
config();

if (!process.env.RPC_URL) {
  throw new Error(BotCaption.InvaildRPC_URL);
}
const connection = new Connection(process.env.RPC_URL, "confirmed");
const metaplex = new Metaplex(connection);

(async () => {
  const accounts = await connection.getParsedProgramAccounts(
    new PublicKey("TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"),
    {
      filters: [
        {
          dataSize: 165, // size of account (bytes)
        },
        {
          memcmp: {
            offset: 0, // number of bytes
            bytes: "AG3Fwm6iin4uJoszMix9mPsWdTjYRuNb3da5JtdTa3u4", // base58 encoded string
          },
        },
      ],
    }
  );
  console.log(JSON.stringify(accounts[0], null, 2))
  const uniqueHolders = new Set();
  let cnt = 0;
  accounts.forEach((account) => {
    const parsedAccountInfo = account.account.data;
    if("parsed" in parsedAccountInfo){
      const tokenBalance = parsedAccountInfo["parsed"]["info"]["tokenAmount"]["uiAmount"];
      if (tokenBalance > 0) {
        uniqueHolders.add(parsedAccountInfo["parsed"]["info"]["owner"]);
        cnt++;
      }
    }
  });
  console.log(cnt)

  // const binaryFile = fs.readFileSync("./chart.png");
  // // const binaryData = new Uint8Array([...]); // Your image data
  // const blob = new Blob([binaryFile], { type: 'image/jpeg' }); // Adjust type as needed
  // const blobUri = URL.createObjectURL(blob);
  // const myImagefile = new File([blob], 'chart.png', { type: blob.type });
  // console.log('Blob URI:', blobUri);
  // const payload = {
  //   file: myImagefile,
  //   name: "test of ipfs",
  //   symbol: "test",
  //   description: "test",
  //   twitter: "",
  //   telegram: "",
  //   website: "",
  //   showName: true,
  //   video: ""
  // }
  // const res = await axios.post("https://pump.fun/api/ipfs", payload)
  // console.log(res.data)

  // console.log(await getSolBalance(connection, new PublicKey("DfMxre4cKmvogbLrPigxmibVTTQDuzjdXojWzjCXXhzj")));
  // console.log(await connection.getBalance(new PublicKey("DfMxre4cKmvogbLrPigxmibVTTQDuzjdXojWzjCXXhzj")));

//   return uniqueHolders.size;
// }
  // console.log(pools)
  // const pools = await connection.getTokenAccountsByOwner(new PublicKey("EsRRJgL3tTHPKn7A372t1qg7mMhHY99AZQ1FQwmxoFRA"), {programId: new PublicKey("TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA")});
  // console.log(pools)
  // pools.value.forEach((spl, index) => {
  //   console.log(index, spl.pubkey.toBase58())
  // })

  // connection.onLogs(new PublicKey("2ois1yQ7pEQjQkjohnN9rYBk8HWmAfCStWCFzc535W72"), log => {
  //   console.log(log)
  // })

  // const splAddress = new PublicKey("68LHL8enesHN7eWAcZ7wXiYwVhbARqBX9p48okV1pump");
  // const PUMP_FUN_PROGRAM = new PublicKey("6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P");
  // const [bondAddress] = PublicKey.findProgramAddressSync( [ Buffer.from("bonding-curve"), splAddress.toBuffer() ], PUMP_FUN_PROGRAM);

//   const GLOBAL = new PublicKey("4wTV1YmiEkRvAtNtsSGPtUrqRYQMe5SKy2uB4Jjaxnjf");
// const PUMP_FEE_RECIPIENT = new PublicKey("CebN5WGQ4jvEPvsVU4EoHEpgzq1VV7AbicfhtW4xC9iM");
// const RENT = new PublicKey("SysvarRent111111111111111111111111111111111");
// const EVENT_AUTHORITY = new PublicKey("Ce6TQqeHC9p8KetsN6JsjHK7UTZk7nasjjnr7XxXp9F1");
// const MINT_AUTHORITY = new PublicKey("TSLvdd1pWpHVjahSpsvCXUbgwsL3JAcvokwaKt1eokM");
// const MPL_TOKEN_METADATA = new PublicKey("metaqbxxUerdq28cj1RbAWkYQm3ybzjb6a8bt518x1s");
// const BLOXROUT_RECEIVER = new PublicKey("HWEoBxYs7ssKuudEjzjmpfJVX7Dvi7wescFsVx2L5yoY");
// const SYSTEM_PROGRAM = SystemProgram.programId;
// const PUMP_FUN_PROGRAM = new PublicKey("6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P");
// const TOKEN_PROGRAM = new PublicKey('TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA');
// const ASSOCIATED_TOKEN_PROGRAM = new PublicKey('ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL');
// const TOKEN_2022_PROGRAM = new PublicKey('TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb');
// const NATIVE_MINT = new PublicKey('So11111111111111111111111111111111111111112');
// const NATIVE_MINT_2022 = new PublicKey('9pan9bMn5HatX4EJdBwg9VgCa7Uz5HL8N1m5D3NdXejP');
//   const mint = new PublicKey("hMSqwW5kz1AF42n7JPfsHSZ1QFFdWrCiwNevv7hpump")
//   const [bondingCurve] = PublicKey.findProgramAddressSync( [ Buffer.from("bonding-curve"), mint.toBuffer() ], PUMP_FUN_PROGRAM);
//   const [associatedBondingCurve] = PublicKey.findProgramAddressSync( [bondingCurve.toBuffer(), TOKEN_PROGRAM.toBuffer(), mint.toBuffer()], ASSOCIATED_TOKEN_PROGRAM );
//   const [metadata] = PublicKey.findProgramAddressSync( [Buffer.from("metadata"), MPL_TOKEN_METADATA.toBuffer(), mint.toBuffer()], MPL_TOKEN_METADATA );
//   console.log(associatedBondingCurve, metadata)

  // 2Po86JrMBf21otTH9tHuBpjzvVxqNRGC2b3PMRkSJKSL
  // 2Po86JrMBf21otTH9tHuBpjzvVxqNRGC2b3PMRkSJKSL

  // D1qHurDQAnr5cS9RvyTpFuLcSbJWEjEd1mQy3azGC8A1
  // metaqbxxUerdq28cj1RbAWkYQm3ybzjb6a8bt518x1s
  // const Txns = await connection.getSignaturesForAddress(new PublicKey("6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P"))
  
  // // const Txns = await connection.getSignaturesForAddress(bondAddress)
  // if ( Txns.length ) {
  //   for ( let k = 0; k< Txns.length; k++ ) {
  //     const txDetail = await connection.getParsedTransaction(Txns[k].signature, {maxSupportedTransactionVersion: 0});
  //     if(txDetail?.meta?.logMessages?.some(item => item.includes("setParams"))){
  //       logger.critical(`${Txns[k].signature}`);
  //     }
  //     logger.info(`${Txns[k].signature}`)
  //   }
  //   logger.error(Txns[Txns.length - 1].signature)
  // }

  // console.log(bondHistory.sort((a, b) => b.blocktime - a.blocktime))

  // const Txn = "3DYtH9JKDQaxtLApexHvxfSBriE1FZu6uxB8iqYv3kgq4by19wPQb3AKvQ2LCznSQXtRm7j2NL6qBfH3Vam9Ae6D";
  // const bal = await signature2solbalance(connection, Txn);
  // console.log(bal)

  // const solVA = new PublicKey("EuVTNU5Q4v7AURBcCQM1aw3YgEj4UfhqD8nzxay4YCEn")
  // const splProgramId  = new PublicKey("TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA")
  // const splVA = await connection.getTokenAccountsByOwner(solVA, {programId: splProgramId});
  // console.log(JSON.stringify(splVA, null, 2))
  // 🕊🐜
  // const meta = await connection.getParsedTransaction("4T94FuJdxq8LdBL3H6AYdmQximgd2WPcD4iEJ5tnJnbV42C3vC1Fr1HLdUBjr7cjaNKeGqXZPryFbF2uvVRyoHew", {
  //   maxSupportedTransactionVersion: 0
  // })
  // console.log(JSON.stringify(meta?.transaction.message.instructions, null, 2));//🦞🦂🐢🐝
  // console.log(JSON.stringify(meta?.meta?.postTokenBalances, null, 2));
  // console.log(JSON.stringify(meta?.meta?.logMessages, null, 2));
  // console.log(JSON.stringify(meta?.transaction.message.accountKeys, null, 2));
  // console.log(meta)
  // const mintAddress =  new PublicKey("8VhSzUQH3s9Vbg7PN425gjb2Q3KSMTam4cHV5rStVXtz");
  // const metadata = await metaplex
  //       .nfts()
  //       .findByMint({mintAddress});
  // console.log(JSON.stringify(metadata.symbol,null,2));
  // const market = await connection.getParsedAccountInfo(new PublicKey("G4C4G8Lqn1x14STtiVisKPMVrMPry5JqcBfxiQ7j7svU"));
  // console.log(market);
  // const kkk = Buffer.from("4ebbea927a3f59162fb63a0deb1424aa1d9c8e362adbb5533af07568563f3954c055e87ae82ce0db43974f01764157efa43fa86196a6f8322394910c83544cee82167633cd8e4b873349af24868323050fe535b9f14136c3e46f05d211f3bcba8cd384019056e4f66a5b1dc6e5529146841ba3a4f5fe80d54c0f2d83bb543c7cad603c03939cadb1c1f3b87429ccb4b2a43f7adc17955ccace44d231e670f54f167d2e9a38744495c8fdb3dde3b707ec65e0d8aa181c9d738f32d0d19031c2bb2f450df315dfced709e0dc07bea4b55b2aa70b4743c0bd299e2f387734b7873824622e7d2f24deafb3c6b3934b1edbcc20b2939febd583fa77265d669b043ef3", 'hex')
  // console.log(kkk.toLocaleString())

  // const accountinfo = await connection.getParsedAccountInfo(new PublicKey('F8xqBxVNa1q52MyAdepMEN6WKF4QcfWmNqGAtrj2pump'))
  // console.log(JSON.stringify(accountinfo,null,2))
})();


// 0.0630398082339993
// 0.0630399999975869
// 0.0630417834612945

