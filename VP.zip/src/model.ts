import { Schema, model, Document } from "mongoose";

// Define user schema and model
interface IHistory extends Document {
  bcAddress: string;
  splAddress: string;
  percent: number;
  messageId: number;
}

const HistorySchema: Schema = new Schema<IHistory>(
  {
    bcAddress: { type: String, required: true },
    splAddress: { type: String, required: true },
    percent: { type: Number, required: true },
    messageId: { type: Number, required: true },
  },
  { timestamps: true }
);

const History = model<IHistory>("History", HistorySchema, "history");

export { History, IHistory };