export function searchForInitialize2(transaction:any) {
  const logMessages = transaction.meta?.logMessages || [];
  if (logMessages.some((log:any) => log.includes(""))) {
    return transaction;
  }
}
