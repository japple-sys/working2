import { Connection, PublicKey } from "@solana/web3.js";

async function getSplfromInitiate(connection:Connection, signaturee: string) {
  const Txn = await connection.getParsedTransaction(signaturee, { commitment: "confirmed", maxSupportedTransactionVersion: 0 });
  console.log(Txn?.transaction.message.instructions)
  const Ixns = Txn?.transaction.message.instructions || [];
  for (const Ixn of Ixns){
      if ("accounts" in Ixn){
          const accounts = Ixn.accounts;
          const mint = accounts[9].toBase58();
          return mint;
      }
  }
  return null;
}

function sol2percent(lamport:any): any {
  // console.log("lamport:",lamport);
  let sol = lamport/1000000000;
  // console.log("sol",sol);
  const a = 0.0002282741184011863
  const b = -0.045003045117231084
  const c = 3.352603448236196
  const d = 1.7112430907482672

  let progress_percentages = a * sol**3 + b * sol**2  + c* sol + d;
  // console.log("percent",progress_percentages);
  
  return progress_percentages;
}

export async function signature2solbalance(connection:Connection, signature:string) {
  let lamports;
  const TxnDetail = await connection.getParsedTransaction(signature, {maxSupportedTransactionVersion:0});
  const tempA = TxnDetail?.meta?.postBalances
  if ( tempA && tempA.length > 0 ) {
    tempA.forEach(item => {
      if ( item.toString().length == 11 ) {
        lamports = item
      }
    })
  }
  const blocktime = TxnDetail?.blockTime
  return {blocktime, lamports};
}

export async function isGraduated(connection:Connection, splToken:string) {
  const PUMP_FUN_PROGRAM = new PublicKey("6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P");
  const [bondingCurve] = PublicKey.findProgramAddressSync( [ Buffer.from("bonding-curve"), new PublicKey(splToken).toBuffer() ], PUMP_FUN_PROGRAM);
  console.log(bondingCurve)
  // const isCompleted = Boolean((await connection.getParsedAccountInfo(bondingCurve)).value?.data.toString('hex').at(-1) == '1')
  const isCompleted = (await connection.getParsedAccountInfo(bondingCurve)).value?.data.toString('hex')
  return isCompleted
}

export async function getRaydiumPools(splToken:string, poolType:string = 'all', poolSortField:string = 'liquidity', sortType:string = 'desc', pageSize:number = 1, page:number = 1) {
  const response = await fetch(`https://api-v3.raydium.io/pools/info/mint?mint1=${splToken}&poolType=${poolType}&poolSortField=${poolSortField}&sortType=${sortType}&pageSize=${pageSize}&page=${page}`);
  const data = await response.json();
  return data;
}