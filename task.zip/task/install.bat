@echo off
echo Installing Node.js dependencies...

:: Check if Node.js is installed
where node >nul 2>nul
if %errorlevel% neq 0 (
    echo Node.js is not installed. Please install Node.js first.
    exit /b
)

:: Navigate to the project directory (change this to your project path)
cd /d "C:\path\to\your\project"

:: Install dependencies
npm install

echo Dependencies installed successfully.
pause