import { clusterApiUrl, Keypair, Connection, LAMPORTS_PER_SOL } from "@solana/web3.js";
import bs58 from "bs58";
import readline from 'readline'
import { getTokenDecimals } from "./utils";
import { getSwapInfo } from "./jupiterService";
import { NATIVE_MINT } from "@solana/spl-token";
import { executeTransaction, getTransaction, signTransaction } from "./transactions";
import { getJitoBundle, sendBundle } from "./jitoService";
import { Wallet } from "@project-serum/anchor";

import dotenv from 'dotenv';
// dotenv.config({
//   path: '../.env'
// })
// const TOKEN_ADDRESS = process.argv[0];
// console.log("TOKEN_ADDRESS", TOKEN_ADDRESS);
function formatTime(date:any) {
  const hours = String(date.getHours()).padStart(2, '0');
  const minutes = String(date.getMinutes()).padStart(2, '0');
  const seconds = String(date.getSeconds()).padStart(2, '0');
  const milliseconds = String(date.getMilliseconds()).padStart(3, '0');
  return `${hours}:${minutes}:${seconds}:${milliseconds}`;
}
const startTime = formatTime(new Date());
// console.log(`⏲ Time Started: ${startTime}`);🚩
dotenv.config()
const buyAndSell = async () => {
  const testConnection = new Connection(clusterApiUrl("devnet"), "confirmed"); // devnet
  const RPC_URL = process.env.RPC_URL;
  // console.log("RPC_URL",RPC_URL);
  if (!RPC_URL) { throw new Error("RPC_URL is not defined in the environment variables."); }
  const buyerWallet = process.env.PRIVATE_KEY;
  if (!buyerWallet) { throw new Error("PRIVATE_KEY is not defined in the environment variables."); }
  const connection = new Connection(RPC_URL, "confirmed"); 
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
  });
  // Input Token address
  // const TOKEN_ADDRESS = await new Promise<string>((resolve) => {
  //   rl.question('Enter the token mint address: ', resolve);
  // });
  const TOKEN_ADDRESS = process.argv[2];
  // console.log("🍏TOKEN_ADDRESS", TOKEN_ADDRESS);
  // Input Token amount to buy
  // const amount = await new Promise<string>((resolve) => {
  //   rl.question('Enter the token amount to buy(SOL): ', resolve);
  // });
  const amount = "0.001";
  const dTime = formatTime(new Date());
    // console.log(`⏲ Time d: ${dTime}`);🚩
  const tokenDecimals = await getTokenDecimals(connection, TOKEN_ADDRESS);   // a second
  const eTime = formatTime(new Date());
    // console.log(`⏲ Time e: ${eTime}`);🚩
  const slippageBps = parseInt(process.env.SLIPPAGEBPS || "") || 50;
  if (!slippageBps) { throw new Error("SLIPPAGEBPS is not defined in the environment variables."); }

  let success = false;
  while (success == false) {
    const buyer = Keypair.fromSecretKey(bs58.decode(buyerWallet));
    // console.log("GETBalance>> amount: ", await connection.getBalance(buyer.publicKey));
    const buyerAnchorWallet = new Wallet(buyer);
    const CTime = formatTime(new Date());
    // console.log(`⏲ Time c: ${CTime}`);🚩
    const swapinfo = await getSwapInfo(NATIVE_MINT.toBase58(), TOKEN_ADDRESS, parseFloat(amount)*LAMPORTS_PER_SOL, slippageBps);
    // console.log(swapinfo.routePlan[0].swapInfo);🚩
    const transaction = await getTransaction(
      buyerAnchorWallet,
      TOKEN_ADDRESS,
      parseFloat(amount),
      slippageBps,
      tokenDecimals,
    );   // a second
    if (transaction == null) { console.log("transaction is null"); continue; }
    const bTime = formatTime(new Date());
    // console.log(`⏲ Time b: ${bTime}`);🚩
    const signedTx = await signTransaction(
      connection,
      transaction,
      buyerAnchorWallet
    );
    const aTime = formatTime(new Date());
    // console.log(`⏲ Time a: ${aTime}`);🚩
    // const resSimTx = await connection.simulateTransaction(signedTx);
    // console.log("Transaction from Jupiter:",signedTx);
    const restTime = formatTime(new Date());
    // console.log(`⏲ Time Rest: ${restTime}`);🚩
    let bundleResult;
    try {
      bundleResult = await sendBundle(connection, signedTx);
      // bundleResult = await getJitoBundle(connection, signedTxs);
      // console.log("bundleResult: \n", bundleResult);
      const confirmedTime = formatTime(new Date());
      // console.log(`⏲ Time Confirmed: ${confirmedTime}`);🚩
      console.log(`⛳Time started: ${startTime}
🚩Time Confirmed: ${confirmedTime} \n
💸Jito fees: 0.0001 SOL
💰Swap fees: ${swapinfo.routePlan[0].swapInfo.feeAmount}
💹Final amount including fees: ${(parseFloat(swapinfo.routePlan[0].swapInfo.outAmount) - parseFloat(swapinfo.routePlan[0].swapInfo.feeAmount))/1000000000 - 0.0003 } SOL`);
      success = true;
    } catch (error) {
      console.log("error:", error);
      console.log("--------------------Continue to next--------------:");
      await new Promise((resolve) => setTimeout(resolve, 10000));
    }
  }
  // sellerWalletIndex++;
  process.exit(0);
};

buyAndSell();
