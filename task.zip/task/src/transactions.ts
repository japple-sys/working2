import { getResponse, getSwapTransaction } from "./jupiterService";

import { Connection, LAMPORTS_PER_SOL, VersionedTransaction, ComputeBudgetProgram  } from "@solana/web3.js";
import { NATIVE_MINT } from "@solana/spl-token";
import { Wallet } from "@project-serum/anchor";

export const executeTransaction = async (
  connection: Connection,
  swapTransaction: any,
  anchorWallet: Wallet
) => {
  let txid, signature;
  const swapTransactionBuf = Buffer.from(swapTransaction, "base64");
  const latestBlockHash = await connection.getLatestBlockhash();
  const transaction = VersionedTransaction.deserialize(swapTransactionBuf);
  transaction.message.recentBlockhash = latestBlockHash.blockhash;
  transaction.sign([anchorWallet.payer]);
  // sign the transaction
  try {
    // Execute the transaction
    const rawTransaction = transaction.serialize();
    txid = await connection.sendRawTransaction(rawTransaction, {
      skipPreflight: false,
      maxRetries: 5,
    });
    signature = await connection.confirmTransaction({
      blockhash: latestBlockHash.blockhash,
      lastValidBlockHeight: latestBlockHash.lastValidBlockHeight,
      signature: txid,
    });
    return {
      confirm: true,
      signature: txid,
    };
  } catch (error) {
    console.log("error", error);
    console.log("Transaction reconfirm after 10s!");
    await new Promise((resolve) => setTimeout(resolve, 10000));
    return {
      confirm: false,
      signature: "",
    };
  }
};

export const getTransaction = async (
  wallet: Wallet,
  tokenAddress: string,
  sellAmount: number,
  slippageBps: number,
  decimals: number,
) => {
  try {
    // Sell Transaction
    const buyQuoteResponse = await getResponse(
      NATIVE_MINT.toBase58(),
      tokenAddress,
      sellAmount * LAMPORTS_PER_SOL,
      slippageBps
    );
    const swapTransaction = await getSwapTransaction(
      buyQuoteResponse,
      wallet
    );
    
    // Buy Transaction

    return swapTransaction;
  } catch (error) {
    console.log("error", error);
    return null;
  }
};

export const signTransaction = async (connection: Connection, transaction: any, wallet: Wallet): Promise<VersionedTransaction> => {

  const swapTransactionBuf = Buffer.from(transaction, "base64");
  const latestBlockHash = await connection.getLatestBlockhash();
  const tx = VersionedTransaction.deserialize(swapTransactionBuf);
  // console.log({ transaction });
  tx.message.recentBlockhash = latestBlockHash.blockhash;
  tx.sign([wallet.payer]);

  // const res = await connection.simulateTransaction(tx);
  // if (res.value.err) {
  //   console.log("- Error -", res.value.err);
  //   console.log("res", res);
  // }
  return tx;
};
