User Guide
1) Install node modules :: use install.bat file
2) go to dist folder and enjoy buy/sell scripts
  buy command: node buy.js tokenaddress
  sell command: node sell.js tokenaddress
Thanks for your consideration